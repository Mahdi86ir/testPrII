import './End.css'



export default function End() {
  return (
    <div className='results'>
      <h2>اطلاعات شما با موفقیت ثبت شد😊</h2>
      <span>
          <button type="button" className='btn'>بازگشت</button>
      </span>
    </div>
  )
}
